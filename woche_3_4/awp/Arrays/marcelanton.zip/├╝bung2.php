<?php

$array = [1020, 923, 780, 890];
// a
$ds = (!empty($array) ? array_sum($array) / count($array) :0);

echo("Durschnittskilomter: ");
echo($ds);
echo("\n");

// b
$liter = 70;
$verbrauch = ($liter / $ds);

echo($verbrauch * 100);

?>