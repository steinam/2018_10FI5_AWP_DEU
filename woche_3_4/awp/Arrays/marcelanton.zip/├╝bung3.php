<?php

$array = [];

for($i = 0; $i < 10; $i++){
    array_push($array, $i);
}

var_dump($array);

$array2 = array_merge($array);
$array2 = array_reverse($array2);

var_dump($array2)




?>