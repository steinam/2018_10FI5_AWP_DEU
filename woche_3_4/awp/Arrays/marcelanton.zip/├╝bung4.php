<?php
function cleanRow($array){
    $text = " ";
    foreach($array as $number){
        $text .= $number." ";
    }
    print($text);
    echo('br');
}

$array = [];

for ($i = 0; $i < 6;$i++){
    array_push($array, rand(1,49));
}

var_dump($array);

$array2 = [];

for($j = 0; $j < 6; $j++){
    $input = readline("Zahl eingeben: ");
    array_push($array2, $input);
}

echo("\n");

cleanRow($array);
cleanRow($array2);



?>
 