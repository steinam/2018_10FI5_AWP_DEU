<?php

$array = array('Shaq', 'Dave','Fred');

for ($i = 0;$i < count($array);$i++){
    var_dump($array[$i]);
}

unset($array[2]);
echo("---------------------------");
echo("\n");

for ($i = 0;$i < count($array);$i++){
    var_dump($array[$i]);
}
echo("---------------------------");
echo("\n");
array_push($array, "Ushi");

var_dump($array);

?>